#LimitRange与ResourceQuota提交前预检

run_precheck.rb使用空kubeconfig调用kubectl客户端版本查询及两条dry-run生成命令，然后由build_precheck.rb读取十份申请并生成request_precheck.csv、normalized_containers.csv、quota_trajectory.csv、final_usage.json及检查摘要。independent_check.rb单独复算结果。

WITHIN_POLICY和NEEDS_CHANGE只表示输入申请与题内规则的离线比较结果。程序不会创建Namespace、Pod、PVC或ResourceQuota，也不联系API服务器。

Windows11原生PowerShell命令：

    $env:ALE_INPUT_ROOT = (Resolve-Path .\input).Path
    $env:ALE_OUTPUT_ROOT = .\重建结果
    $env:KUBECTL_BIN = (Resolve-Path C:\Tools\kubectl.exe).Path
    ruby .\output\run_precheck.rb

输出目录必须不存在或为空，输入目录保持只读。
