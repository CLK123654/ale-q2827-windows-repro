#!/usr/bin/env ruby
require "csv"
require "json"
require "yaml"

USAGE_KEYS = %w[pods requests_cpu_m requests_memory_mi limits_cpu_m limits_memory_mi persistentvolumeclaims requests_storage_gi].freeze

def cpu(value)
  text = value.to_s
  return text.delete_suffix("m").to_i if text.match?(/\A[0-9]+m\z/)
  return text.to_i * 1000 if text.match?(/\A[0-9]+\z/)
  raise "bad CPU"
end

def memory(value)
  text = value.to_s
  return text.delete_suffix("Mi").to_i if text.match?(/\A[0-9]+Mi\z/)
  return text.delete_suffix("Gi").to_i * 1024 if text.match?(/\A[0-9]+Gi\z/)
  raise "bad memory"
end

def storage(value)
  text = value.to_s
  raise "bad storage" unless text.match?(/\A[0-9]+Gi\z/)
  text.delete_suffix("Gi").to_i
end

def object(path)
  YAML.safe_load(File.read(path, encoding: "UTF-8"), permitted_classes: [], permitted_symbols: [], aliases: false)
end

def csv_rows(path)
  CSV.read(path, headers: true).map(&:to_h)
end

input, policy, results = ARGV.map { |value| File.expand_path(value) }
raise "usage: independent_check.rb INPUT POLICY RESULTS" unless results
contract = JSON.parse(File.read(File.join(input, "precheck_contract.json"), encoding: "UTF-8"))
existing = JSON.parse(File.read(File.join(input, "existing_usage.json"), encoding: "UTF-8"))
limit = object(File.join(policy, "10-limitrange.yaml")).dig("spec", "limits").first
quota = object(File.join(policy, "20-resourcequota.yaml")).dig("spec", "hard")
defaults = {
  "request_cpu_m" => cpu(limit.dig("defaultRequest", "cpu")),
  "request_memory_mi" => memory(limit.dig("defaultRequest", "memory")),
  "limit_cpu_m" => cpu(limit.dig("default", "cpu")),
  "limit_memory_mi" => memory(limit.dig("default", "memory"))
}
bounds = {
  "min_cpu_m" => cpu(limit.dig("min", "cpu")),
  "min_memory_mi" => memory(limit.dig("min", "memory")),
  "max_cpu_m" => cpu(limit.dig("max", "cpu")),
  "max_memory_mi" => memory(limit.dig("max", "memory")),
  "ratio_cpu" => limit.dig("maxLimitRequestRatio", "cpu").to_i,
  "ratio_memory" => limit.dig("maxLimitRequestRatio", "memory").to_i
}
hard = {
  "pods" => quota["pods"].to_i,
  "requests_cpu_m" => cpu(quota["requests.cpu"]),
  "requests_memory_mi" => memory(quota["requests.memory"]),
  "limits_cpu_m" => cpu(quota["limits.cpu"]),
  "limits_memory_mi" => memory(quota["limits.memory"]),
  "persistentvolumeclaims" => quota["persistentvolumeclaims"].to_i,
  "requests_storage_gi" => storage(quota["requests.storage"])
}

normalized = []
ledger = []
usage = existing.dup
trajectory = [{ "request_id" => "INITIAL", "decision" => "BASELINE" }.merge(usage)]
files = contract["exact_input_files"].grep(%r{\Arequests/})
files.each_with_index do |relative, index|
  request = object(File.join(input, relative))
  request_id = request.dig("metadata", "annotations", contract["request_id_annotation"])
  raise "request order drift" unless request_id == contract["request_order"][index]
  kind = request["kind"]
  delta = USAGE_KEYS.to_h { |key| [key, 0] }
  violations = []
  if kind == "Pod"
    delta["pods"] = 1
    request.dig("spec", "containers").each do |container|
      resources = container["resources"] || {}
      req = resources["requests"] || {}
      lim = resources["limits"] || {}
      rcpu = req.key?("cpu") ? cpu(req["cpu"]) : defaults["request_cpu_m"]
      rmem = req.key?("memory") ? memory(req["memory"]) : defaults["request_memory_mi"]
      lcpu = lim.key?("cpu") ? cpu(lim["cpu"]) : defaults["limit_cpu_m"]
      lmem = lim.key?("memory") ? memory(lim["memory"]) : defaults["limit_memory_mi"]
      normalized << {
        "request_id" => request_id, "pod" => request.dig("metadata", "name"), "container" => container["name"],
        "request_cpu_m" => rcpu.to_s, "request_memory_mi" => rmem.to_s, "limit_cpu_m" => lcpu.to_s, "limit_memory_mi" => lmem.to_s,
        "request_cpu_source" => req.key?("cpu") ? "EXPLICIT" : "DEFAULTED",
        "request_memory_source" => req.key?("memory") ? "EXPLICIT" : "DEFAULTED",
        "limit_cpu_source" => lim.key?("cpu") ? "EXPLICIT" : "DEFAULTED",
        "limit_memory_source" => lim.key?("memory") ? "EXPLICIT" : "DEFAULTED"
      }
      violations << "MIN_CPU" if rcpu < bounds["min_cpu_m"]
      violations << "MIN_MEMORY" if rmem < bounds["min_memory_mi"]
      violations << "MAX_CPU" if lcpu > bounds["max_cpu_m"]
      violations << "MAX_MEMORY" if lmem > bounds["max_memory_mi"]
      violations << "RATIO_CPU" if lcpu > bounds["ratio_cpu"] * rcpu
      violations << "RATIO_MEMORY" if lmem > bounds["ratio_memory"] * rmem
      delta["requests_cpu_m"] += rcpu
      delta["requests_memory_mi"] += rmem
      delta["limits_cpu_m"] += lcpu
      delta["limits_memory_mi"] += lmem
    end
  elsif kind == "PersistentVolumeClaim"
    delta["persistentvolumeclaims"] = 1
    delta["requests_storage_gi"] = storage(request.dig("spec", "resources", "requests", "storage"))
  else
    raise "kind drift"
  end
  decision = "WITHIN_POLICY"
  reason = ""
  exceeded = []
  proposal = nil
  unless violations.empty?
    decision = "NEEDS_CHANGE"
    reason = "LIMIT_RANGE"
    exceeded = violations.uniq.sort
  end
  if decision == "WITHIN_POLICY"
    proposal = USAGE_KEYS.to_h { |key| [key, usage[key] + delta[key]] }
    names = { "requests_cpu_m" => "requests.cpu", "requests_memory_mi" => "requests.memory", "limits_cpu_m" => "limits.cpu", "limits_memory_mi" => "limits.memory", "requests_storage_gi" => "requests.storage" }
    exceeded = USAGE_KEYS.select { |key| proposal[key] > hard[key] }.map { |key| names.fetch(key, key) }.sort
    if exceeded.empty?
      usage = proposal
    else
      decision = "NEEDS_CHANGE"
      reason = "RESOURCE_QUOTA"
    end
  end
  row = { "request_id" => request_id, "kind" => kind, "name" => request.dig("metadata", "name"), "decision" => decision, "reason" => reason, "exceeded_resources" => exceeded.join(";") }
  USAGE_KEYS.each { |key| row["proposed_#{key}"] = proposal ? proposal[key].to_s : nil }
  ledger << row
  trajectory << { "request_id" => request_id, "decision" => decision }.merge(USAGE_KEYS.to_h { |key| [key, usage[key].to_s] })
end
expected_initial = { "request_id" => "INITIAL", "decision" => "BASELINE" }.merge(USAGE_KEYS.to_h { |key| [key, existing[key].to_s] })
trajectory[0] = expected_initial

raise "normalized ledger differs" unless csv_rows(File.join(results, "normalized_containers.csv")) == normalized
raise "precheck ledger differs" unless csv_rows(File.join(results, "request_precheck.csv")) == ledger
raise "quota trajectory differs" unless csv_rows(File.join(results, "quota_trajectory.csv")) == trajectory
raise "final usage differs" unless JSON.parse(File.read(File.join(results, "final_usage.json"))) == usage
summary = JSON.parse(File.read(File.join(results, "precheck_summary.json")) )
raise "summary counts differ" unless summary.values_at("requests", "containers", "within_policy", "needs_change", "trajectory_rows", "result_files") == [10, 9, 5, 5, 11, 8]
raise "summary final differs" unless summary["final_usage"] == usage
validation = JSON.parse(File.read(File.join(results, "validation.json")))
raise "validation differs" unless validation["result"] == "PASS" && validation["invariants"].length == 24 && validation["invariants"].values.all?
raise "validation controls differ" unless validation["controls"] == summary
generated_namespace = object(File.join(results, "kubectl_namespace_dry_run.yaml"))
generated_quota = object(File.join(results, "kubectl_quota_dry_run.yaml"))
raise "generated namespace differs" unless generated_namespace["kind"] == "Namespace" && generated_namespace.dig("metadata", "name") == contract["namespace"]
generated_hard = generated_quota.dig("spec", "hard")
generated_units = {
  "pods" => generated_hard["pods"].to_i,
  "requests_cpu_m" => cpu(generated_hard["requests.cpu"]),
  "requests_memory_mi" => memory(generated_hard["requests.memory"]),
  "limits_cpu_m" => cpu(generated_hard["limits.cpu"]),
  "limits_memory_mi" => memory(generated_hard["limits.memory"]),
  "persistentvolumeclaims" => generated_hard["persistentvolumeclaims"].to_i,
  "requests_storage_gi" => storage(generated_hard["requests.storage"])
}
raise "generated quota differs" unless generated_units == hard
puts "kubernetes_internet_sandbox_precheck independent check PASS"
